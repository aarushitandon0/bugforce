def retry(n):
    return n < 3
